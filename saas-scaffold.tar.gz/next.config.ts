import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  // Strict mode for development
  reactStrictMode: true,

  // Server-side only packages (never bundled to client)
  serverExternalPackages: ['@anthropic-ai/sdk', 'stripe', 'resend'],

  // Security headers
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'Referrer-Policy',
            value: 'strict-origin-when-cross-origin',
          },
          {
            key: 'Permissions-Policy',
            value: 'camera=(), microphone=(), geolocation=()',
          },
        ],
      },
    ];
  },
};

export default nextConfig;
